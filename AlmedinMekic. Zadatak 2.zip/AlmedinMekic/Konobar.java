public class Konobar extends Zaposleni {
    double dodatniSati;

    public Konobar(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati, double dodatniSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
        this.dodatniSati = dodatniSati;
    }

    public double obracunPlate() {
        double osnovna = 4 * ukupanBrojSati * plataPoSatu;
        double prekovremeno = dodatniSati * (plataPoSatu * 1.2);
        return osnovna + prekovremeno;
    }

    public String getTip() {
        return "Konobar";
    }
}

public class Kuvar extends Zaposleni {

    public Kuvar(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
    }

    public double obracunPlate() {
        return 1500 + 4 * ukupanBrojSati * plataPoSatu;
    }

    public String getTip() {
        return "Kuvar";
    }
}

public class Main {
    public static void main(String[] args) {
        Restoran r = new Restoran("Bistro", "Njegoseva 5", "12345678");

        Konobar k1 = new Konobar(1, "Almedina", "Metic", 6.5, 40, 5);
        Kuvar k2 = new Kuvar(2, "Imad", "Ilic", 8, 38);
        Menadzer m1 = new Menadzer(3, "Almedin", "Mekic", 10, 35, 300);
        Konobar k3 = new Konobar(4, "Milan", "Milic", 6, 42, 0);
        Kuvar k4 = new Kuvar(5, "Ana", "Anic", 9, 36);

        r.dodajZaposlenog(k1);
        r.dodajZaposlenog(k2);
        r.dodajZaposlenog(m1);
        r.dodajZaposlenog(k3);
        r.dodajZaposlenog(k4);

        r.generisiObracun("Oktobar", 2025);
    }
}

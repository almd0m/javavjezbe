public class Menadzer extends Zaposleni {
    double dodatak;

    public Menadzer(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati, double dodatak) {
        super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
        this.dodatak = dodatak;
    }

    public double obracunPlate() {
        return 1300 + 4 * ukupanBrojSati * plataPoSatu + dodatak;
    }

    public String getTip() {
        return "Menadzer";
    }
}

import java.util.ArrayList;

public class Restoran {
    String imeRestorana;
    String lokacija;
    String pib;
    ArrayList<Zaposleni> osoblje = new ArrayList<>();

    public Restoran(String imeRestorana, String lokacija, String pib) {
        this.imeRestorana = imeRestorana;
        this.lokacija = lokacija;
        this.pib = pib;
    }

    public void dodajZaposlenog(Zaposleni z) {
        osoblje.add(z);
    }

    public void obrisiZaposlenog(int id) {
        Zaposleni zaBrisanje = null;
        for (Zaposleni z : osoblje) {
            if (z.id == id) {
                zaBrisanje = z;
            }
        }
        if (zaBrisanje != null) osoblje.remove(zaBrisanje);
    }

    public Zaposleni pronadjiPoID(int id) {
        for (Zaposleni z : osoblje) {
            if (z.id == id) return z;
        }
        return null;
    }

    public void generisiObracun(String mjesec, int godina) {
        double ukupno = 0;
        System.out.println("ID\tIme i Prezime\tUloga\tSati\tDodatno\tPlata(EUR)");
        for (Zaposleni z : osoblje) {
            double plata = z.obracunPlate();
            String dodatno = "-";
            if (z instanceof Konobar) {
                dodatno = "Prekovr: " + ((Konobar) z).dodatniSati;
            } else if (z instanceof Menadzer) {
                dodatno = "Bonus: " + ((Menadzer) z).dodatak;
            }
            System.out.println(z.id + "\t" + z.ime + " " + z.prezime + "\t" + z.getTip() + "\t" + z.ukupanBrojSati + "\t" + dodatno + "\t" + plata);
            ukupno += plata;
        }
        System.out.println("Ukupan iznos plata: " + ukupno + " EUR");
    }
}

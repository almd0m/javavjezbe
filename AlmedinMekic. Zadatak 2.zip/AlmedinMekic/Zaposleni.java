public class Zaposleni {
    int id;
    String ime;
    String prezime;
    double plataPoSatu;
    double ukupanBrojSati;

    public Zaposleni(int id, String ime, String prezime, double plataPoSatu, double ukupanBrojSati) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.plataPoSatu = plataPoSatu;
        this.ukupanBrojSati = ukupanBrojSati;
    }

    public double obracunPlate() {
        return 0;
    }

    public String getTip() {
        return "Zaposleni";
    }
}
